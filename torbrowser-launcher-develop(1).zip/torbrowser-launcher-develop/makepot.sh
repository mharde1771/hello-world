#!/bin/sh
cd torbrowser_launcher
xgettext --language=Python --from-code=UTF-8 --output=../torbrowser_launcher.pot *.py
